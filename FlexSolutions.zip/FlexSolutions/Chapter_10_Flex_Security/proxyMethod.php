<?php
set_time_limit(0);
$url = $_GET['url'];
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_TIMEOUT, 100);

$response = curl_exec($ch);

if (curl_errno($ch)) {
  print curl_error($ch);
} else {
  curl_close($ch);
  header("Content-type: text/xml");
  header("Content-length:", strlen($response));
  print $response;
}
?>
